﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Define_a_Class_Person
{
    public class Person
    {
        private string name;
        private int age;

        public string Name { get; set; }

        public int Age { get; set; }
    }
}
