﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Define_a_Class_Person
{
    public class StartUp
    {
        static void Main()
        {
            Person p = new Person();

            p.Name = "Emo";
            p.Age = 20;

            Console.WriteLine(p.Name + p.Age);
        }
    }
}
